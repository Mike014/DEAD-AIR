# ENTITÀ System for Unity

Un sistema di AI agentic per NPC con **autonomia temporale**. ENTITÀ decide **SE** e **QUANDO** parlare, non solo **COSA** dire.

## Filosofia

Il silenzio non è assenza — è una scelta.

A differenza dei sistemi NPC tradizionali che rispondono sempre, ENTITÀ usa un **Temporal Controller** che:
- Accumula percezione del tempo (EMA multi-scala)
- Mantiene uno stato emotivo con isteresi
- Decide stocasticamente se intervenire
- Si auto-limita per non essere invadente

## Installazione

### Via Package Manager (consigliato)

1. Apri Window → Package Manager
2. Click `+` → Add package from git URL
3. Incolla: `https://github.com/yourusername/EntitySystem.git`

### Via copia manuale

1. Copia la cartella `EntitySystem` in `Assets/Packages/`
2. Unity importerà automaticamente

## Quick Start

```csharp
using UnityEngine;
using EntitySystem;

public class MyNPC : MonoBehaviour
{
    [SerializeField] private EntityBrain _entity;
    
    private float _narrativeTension = 0.5f;
    
    void Update()
    {
        // Aggiorna la tensione basandoti sul gameplay
        _narrativeTension = CalculateTension();
        
        // Ogni tanto, chiedi a ENTITÀ se vuole parlare
        if (ShouldQuery())
        {
            string context = GetDialogContext();
            _entity.Query(context, _narrativeTension);
        }
    }
    
    void OnEnable()
    {
        _entity.OnEntitySpeak.AddListener(OnSpeak);
        _entity.OnEntitySilence.AddListener(OnSilence);
    }
    
    void OnSpeak(string text)
    {
        Debug.Log($"ENTITÀ dice: {text}");
        // Mostra il testo, attiva TTS, etc.
    }
    
    void OnSilence()
    {
        // ENTITÀ ha scelto di restare in silenzio
        // Questo È gameplay, non un errore
    }
}
```

## Configurazione

### TemporalConfig (ScriptableObject)

Crea via: `Assets → Create → Entity → Temporal Config`

| Parametro | Default | Descrizione |
|-----------|---------|-------------|
| `baseProb` | 0.65 | Probabilità base di intervento |
| `hardCooldown` | 5s | Tempo minimo tra interventi |
| `hlShort/Mid/Long` | 4/15/90s | Half-life per EMA |
| `probFloor/Ceil` | 0.05/0.75 | Limiti probabilità |

### API Key

Imposta `GROQ_API_KEY` come variabile d'ambiente, oppure inseriscila direttamente nel componente EntityBrain (non consigliato per build pubbliche).

## Architettura

```
┌─────────────────────────────────────────┐
│              EntityBrain                │
│           (MonoBehaviour)               │
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────────────┐  ┌──────────────┐  │
│  │   Temporal      │  │    Groq      │  │
│  │   Controller    │──│    Client    │  │
│  │   (C# native)   │  │   (remote)   │  │
│  └─────────────────┘  └──────────────┘  │
│           │                    │        │
│     ShouldSpeak()        GenerateResponse()
│      ~0.1ms                ~500-1500ms  │
│                                         │
└─────────────────────────────────────────┘
```

**Flusso:**
1. `Query()` chiamato con contesto e tensione
2. `TemporalController.ShouldSpeak()` decide localmente (~0.1ms)
3. Se `true`, chiama Groq API per generare la frase
4. Valida e filtra la risposta
5. Emette `OnEntitySpeak` o `OnEntitySilence`

## Debug

### EntityDebugUI

Aggiungi il componente `EntityDebugUI` per visualizzare in tempo reale:
- Stato emotivo (Curious/Bored/Irritated)
- Probabilità corrente
- EMA di tensione e silenzio
- Contatori e rate

Toggle con `F1`.

### EntityMetricsLogger

Genera un CSV compatibile con il formato Python per analisi unificate:

```csv
ts,event,model,decision_ms,p,speak,...,emotion
1758901227.258,response,unity-native,,0.545,True,...,curious
```

## Stati Emotivi

| Stato | Bias | Trigger |
|-------|------|---------|
| **Curious** | +0.12 | Default, dopo aver parlato |
| **Bored** | -0.08 | Bassa tensione + silenzio |
| **Irritated** | +0.22 | Alta tensione + silenzio prolungato |

Le transizioni hanno **isteresi** (minimo 5s tra cambi) per evitare flip rapidi.

## Estensioni

### Custom Time Provider

Per sistemi con tempo di gioco diverso da `Time.time`:

```csharp
var controller = new TemporalController(
    config,
    timeProvider: () => GameTime.current
);
```

### Force Speak

Per eventi scriptati che bypassano il gate:

```csharp
_entity.ForceSpeak(dialogContext);
```

### Reset

Per nuova sessione/scena:

```csharp
_entity.Reset();
```

## Differenze dal Prototipo Python

| Aspetto | Python | Unity |
|---------|--------|-------|
| Temporal Controller | `entity_brain.py` | `TemporalController.cs` |
| LLM Client | `groq` SDK | `UnityWebRequest` |
| Validazione | Regex Python | Regex C# (stesso pattern) |
| Metriche | CSV via `csv` module | CSV via `File.AppendAllText` |
| OS Integration | `EntityDirector` | Non incluso (futuro) |

## Roadmap

- [ ] Port di EntityDirector (OS notifications, desktop notes)
- [ ] TTS integration (ElevenLabs)
- [ ] WebVoyager equivalent (Selenium → Puppeteer Sharp?)
- [ ] Unity Sentis per inferenza locale

## Licenza

Proprietario — contatta l'autore per uso commerciale.

## Autore

**Michele Grimaldi**  
E-C-H-O SYSTEMS  
mikgrimaldi7@gmail.com
