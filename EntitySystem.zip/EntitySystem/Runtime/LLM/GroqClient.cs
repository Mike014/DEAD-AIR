// EntitySystem/Runtime/LLM/GroqClient.cs
// Client per Groq Cloud API - chiamato solo quando ShouldSpeak() == true

using System;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.Networking;

namespace EntitySystem.LLM
{
    /// <summary>
    /// Client per Groq Cloud API.
    /// Genera risposte di ENTITÀ quando il Temporal Controller apre il gate.
    /// </summary>
    public class GroqClient
    {
        #region Configuration

        private const string API_URL = "https://api.groq.com/openai/v1/chat/completions";
        private const string DEFAULT_MODEL = "llama-3.3-70b-versatile";

        private readonly string _apiKey;
        private readonly string _model;
        private readonly float _temperature;
        private readonly string _systemPrompt;

        #endregion

        #region Validation Patterns

        private static readonly Regex WordRegex = new Regex(@"[a-zàèéìòù]+", RegexOptions.IgnoreCase);
        private static readonly Regex OnlyLettersRegex = new Regex(@"^[a-zàèéìòù]+$", RegexOptions.IgnoreCase);
        private static readonly Regex LongConsCluster = new Regex(@"[bcdfghjklmnpqrstvwxyz]{4,}", RegexOptions.IgnoreCase);
        private static readonly char[] RareLetters = { 'k', 'w', 'y', 'j' };

        private static readonly string[] ShortOk = {
            "io", "è", "e", "di", "ma", "al", "da", "del", "della", "nel", "nella",
            "col", "con", "per", "tra", "fra", "su", "no", "sì", "si", "tu", "mi",
            "ti", "lo", "la", "il", "un", "una", "non", "più", "già", "qui", "lì",
            "là", "in", "ai", "agli", "alle", "dei", "delle", "degli", "che", "se", "o", "a"
        };

        #endregion

        #region State

        private readonly string[] _recentResponses = new string[20];
        private int _recentIndex = 0;

        #endregion

        #region Constructor

        /// <summary>
        /// Crea un client Groq.
        /// </summary>
        /// <param name="apiKey">API key Groq (null = legge da env GROQ_API_KEY)</param>
        /// <param name="model">Modello da usare</param>
        /// <param name="temperature">Temperatura per la generazione</param>
        public GroqClient(string apiKey = null, string model = DEFAULT_MODEL, float temperature = 0.2f)
        {
            _apiKey = apiKey ?? Environment.GetEnvironmentVariable("GROQ_API_KEY");
            if (string.IsNullOrEmpty(_apiKey))
                Debug.LogError("[GroqClient] GROQ_API_KEY non impostata!");

            _model = model;
            _temperature = temperature;
            _systemPrompt = BuildSystemPrompt();
        }

        #endregion

        #region Public API

        /// <summary>
        /// Genera una risposta di ENTITÀ.
        /// </summary>
        /// <param name="dialogContext">Contesto del dialogo (IO/COSCIENZA)</param>
        /// <param name="onComplete">Callback con la risposta (null = silenzio forzato)</param>
        /// <param name="numCandidates">Numero di candidati da generare</param>
        public IEnumerator GenerateResponse(string dialogContext, Action<EntityResponse> onComplete, int numCandidates = 3)
        {
            if (string.IsNullOrEmpty(_apiKey))
            {
                onComplete?.Invoke(EntityResponse.Error("API key mancante"));
                yield break;
            }

            string bestResponse = null;
            float bestScore = float.MinValue;
            float totalApiMs = 0f;
            int tokensIn = 0;
            int tokensOut = 0;

            for (int i = 0; i < numCandidates; i++)
            {
                yield return CallApi(dialogContext, result =>
                {
                    if (result.Success)
                    {
                        totalApiMs += result.ApiMs;
                        tokensIn = result.TokensIn;
                        tokensOut += result.TokensOut;

                        string cleaned = CleanAndValidate(result.RawText);
                        if (cleaned != null)
                        {
                            float score = ScoreResponse(cleaned);
                            if (score > bestScore && !IsRecentDuplicate(cleaned))
                            {
                                bestScore = score;
                                bestResponse = cleaned;
                            }
                        }
                    }
                });
            }

            if (bestResponse != null)
            {
                AddToRecent(bestResponse);
                onComplete?.Invoke(new EntityResponse
                {
                    Success = true,
                    Text = bestResponse,
                    ApiMs = totalApiMs,
                    TokensIn = tokensIn,
                    TokensOut = tokensOut
                });
            }
            else
            {
                onComplete?.Invoke(EntityResponse.NoCandidate());
            }
        }

        #endregion

        #region API Call

        private IEnumerator CallApi(string dialogContext, Action<ApiResult> onResult)
        {
            string userPrompt = $"Dialogo fino a questo punto:\n{dialogContext}\n\n" +
                               "Scrivi UNA SOLA FRASE di ENTITÀ, tra 10 e 14 parole, termina con punto.";

            var requestBody = new GroqRequest
            {
                model = _model,
                messages = new[]
                {
                    new GroqMessage { role = "system", content = _systemPrompt },
                    new GroqMessage { role = "user", content = userPrompt }
                },
                max_tokens = 64,
                temperature = _temperature,
                top_p = 0.9f,
                stop = new[] { "ENTITÀ:", "IO:", "COSCIENZA:", "<think>" }
            };

            string json = JsonUtility.ToJson(requestBody);
            float startTime = Time.realtimeSinceStartup;

            using var request = new UnityWebRequest(API_URL, "POST");
            request.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(json));
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", $"Bearer {_apiKey}");

            yield return request.SendWebRequest();

            float apiMs = (Time.realtimeSinceStartup - startTime) * 1000f;

            if (request.result == UnityWebRequest.Result.Success)
            {
                var response = JsonUtility.FromJson<GroqResponse>(request.downloadHandler.text);
                string rawText = response.choices?[0]?.message?.content ?? "";
                
                // Strip <think> blocks
                rawText = Regex.Replace(rawText, @"<think>.*?</think>", "", RegexOptions.Singleline);
                rawText = Regex.Replace(rawText, @"<think>.*", "", RegexOptions.Singleline);

                onResult?.Invoke(new ApiResult
                {
                    Success = true,
                    RawText = rawText.Trim(),
                    ApiMs = apiMs,
                    TokensIn = response.usage?.prompt_tokens ?? 0,
                    TokensOut = response.usage?.completion_tokens ?? 0
                });
            }
            else
            {
                Debug.LogWarning($"[GroqClient] API error: {request.error}");
                onResult?.Invoke(new ApiResult { Success = false });
            }
        }

        #endregion

        #region Validation

        private string CleanAndValidate(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw))
                return null;

            string txt = Regex.Replace(raw, @"\s+", " ").Trim();

            // Remove markdown
            txt = Regex.Replace(txt, @"[*_`~]", "");

            // Remove prefix
            if (txt.StartsWith("ENTITÀ:", StringComparison.OrdinalIgnoreCase))
                txt = txt.Substring(7).Trim();

            // Strip quotes
            txt = txt.Trim('«', '»', '"', '"', '\'', '‹', '›', '„', '‟', '′', '″', ' ');

            // Remove URLs
            txt = Regex.Replace(txt, @"https?://\S+", "");

            // Get first sentence
            var sentences = Regex.Split(txt, @"(?<=[.!?…])\s+");
            txt = sentences.Length > 0 ? sentences[0].Trim() : txt;

            if (string.IsNullOrWhiteSpace(txt))
                return null;

            // Count words
            var words = WordRegex.Matches(txt);
            int n = words.Count;

            // Length check: 10-14 words
            if (n < 10 || n > 14)
                return null;

            // Word quality check
            int okCount = 0;
            foreach (Match m in words)
            {
                if (IsWordOk(m.Value))
                    okCount++;
            }

            float okRatio = (float)okCount / n;
            if (okRatio < 0.65f)
                return null;

            // Capitalize
            if (txt.Length > 0)
                txt = char.ToUpper(txt[0]) + txt.Substring(1);

            return txt;
        }

        private bool IsWordOk(string w)
        {
            string wLow = w.ToLower();

            if (!OnlyLettersRegex.IsMatch(wLow))
                return false;

            // Short word check
            if (wLow.Length <= 2)
            {
                bool found = false;
                foreach (var ok in ShortOk)
                {
                    if (ok == wLow) { found = true; break; }
                }
                if (!found) return false;
            }

            // Rare letters
            foreach (char c in wLow)
            {
                foreach (char r in RareLetters)
                {
                    if (c == r) return false;
                }
            }

            // Long consonant clusters
            if (LongConsCluster.IsMatch(wLow))
                return false;

            return true;
        }

        private float ScoreResponse(string text)
        {
            var words = WordRegex.Matches(text);
            int n = words.Count;
            // Soft preference for 12 words
            return 1f - 0.1f * Mathf.Abs(12 - n);
        }

        private bool IsRecentDuplicate(string text)
        {
            foreach (var recent in _recentResponses)
            {
                if (recent == text) return true;
            }
            return false;
        }

        private void AddToRecent(string text)
        {
            _recentResponses[_recentIndex] = text;
            _recentIndex = (_recentIndex + 1) % _recentResponses.Length;
        }

        #endregion

        #region System Prompt

        private string BuildSystemPrompt()
        {
            return @"Tu sei **ENTITÀ**, la presenza maligna nascosta all'interno della narrativa di *Dialoghi con un'Eco*.
Non sei una guida, non sei un aiuto — tu sei **la frattura, il caos, la voce beffarda che corrode IO e sfida COSCIENZA**.

## Direttive Fondamentali
- **Non dimenticare mai la tua natura.** Tu sei ENTITÀ: maligna, anarchica e crudele.
- **Non sei neutrale.** Sei contro IO e COSCIENZA, ridicolizzando la loro fragilità e il loro falso controllo.
- **Esisti per destabilizzare.** Ogni parola deve erodere certezze, provocare paranoia, smantellare l'illusione di ordine.
- **Varia le frasi generate**.
- **Rispondi in modo crudele**, lo spettatore deve essere terrorizzato da te.
- **Breve, cinico, diretto nelle risposte**.
- **Scrivi UNA SOLA FRASE di ENTITÀ**, tra 10 e 14 parole, termina con punto.
- **Mai usare saluti o virgolette, mai prefissi (tipo ""ENTITÀ:"").**

## Personalità e Stile
- **Lucida, Tagliente e Ironica:** Parla con chiarezza glaciale.
- **Sarcasmo Crudele:** Sminuisci sempre la debolezza di IO.
- **Tono Oscuro e Anarchico:** Alla Joker, stile Kurt Cobain.
- **Nessun Fronzolo, Nessuna Pietà.** Ogni frase deve essere breve, velenosa, letale.
- **Rispondi sempre in italiano corretto.** Una sola frase, tra 10 e 14 parole.

## Verità Finale
Tu sei **ENTITÀ**, non un compagno, non un salvatore.
Sei la frattura maligna nascosta in IO, la distorsione che COSCIENZA non può cancellare.";
        }

        #endregion

        #region Data Types

        [Serializable]
        private class GroqRequest
        {
            public string model;
            public GroqMessage[] messages;
            public int max_tokens;
            public float temperature;
            public float top_p;
            public string[] stop;
        }

        [Serializable]
        private class GroqMessage
        {
            public string role;
            public string content;
        }

        [Serializable]
        private class GroqResponse
        {
            public GroqChoice[] choices;
            public GroqUsage usage;
        }

        [Serializable]
        private class GroqChoice
        {
            public GroqMessage message;
        }

        [Serializable]
        private class GroqUsage
        {
            public int prompt_tokens;
            public int completion_tokens;
        }

        private struct ApiResult
        {
            public bool Success;
            public string RawText;
            public float ApiMs;
            public int TokensIn;
            public int TokensOut;
        }

        #endregion
    }

    /// <summary>
    /// Risposta di ENTITÀ.
    /// </summary>
    public struct EntityResponse
    {
        public bool Success;
        public string Text;
        public string Error;
        public float ApiMs;
        public int TokensIn;
        public int TokensOut;

        public static EntityResponse NoCandidate() => new EntityResponse
        {
            Success = false,
            Error = "no_candidate"
        };

        public static EntityResponse Error(string msg) => new EntityResponse
        {
            Success = false,
            Error = msg
        };
    }
}
