// EntitySystem/Runtime/Core/TemporalConfig.cs
// Configurazione del Temporal Controller - parametri calibrati dal prototipo Python

using System;
using UnityEngine;

namespace EntitySystem.Core
{
    /// <summary>
    /// Configurazione immutabile per il TemporalController.
    /// I valori di default corrispondono al prototipo Python calibrato.
    /// </summary>
    [CreateAssetMenu(fileName = "TemporalConfig", menuName = "Entity/Temporal Config")]
    public class TemporalConfig : ScriptableObject
    {
        [Header("Probabilità Base")]
        [Tooltip("Probabilità base di intervento (prima dei modificatori)")]
        [Range(0f, 1f)]
        public float baseProb = 0.65f;

        [Header("Pesi della Formula")]
        [Tooltip("Peso della tensione narrativa nella decisione")]
        [Range(0f, 1f)]
        public float wTension = 0.30f;

        [Tooltip("Peso della memoria di silenzio accumulato")]
        [Range(0f, 1f)]
        public float wMemory = 0.20f;

        [Tooltip("Peso dello stato emotivo corrente")]
        [Range(0f, 1f)]
        public float wEmotion = 0.25f;

        [Tooltip("Peso dei boost temporali (gap di silenzio)")]
        [Range(0f, 1f)]
        public float wTemporal = 0.08f;

        [Tooltip("Peso del rumore stocastico")]
        [Range(0f, 0.2f)]
        public float wRandom = 0.05f;

        [Header("Limiti Probabilità")]
        [Tooltip("Probabilità minima (ENTITÀ non è mai completamente muta)")]
        [Range(0f, 0.2f)]
        public float probFloor = 0.05f;

        [Tooltip("Probabilità massima (ENTITÀ non è mai troppo invadente)")]
        [Range(0.5f, 1f)]
        public float probCeil = 0.75f;

        [Header("Timing")]
        [Tooltip("Cooldown dopo un intervento (secondi)")]
        [Range(1f, 30f)]
        public float hardCooldown = 5f;

        [Tooltip("Gap minimo per boost 'micro' (secondi)")]
        [Range(1f, 10f)]
        public float minGapMicro = 2f;

        [Tooltip("Gap minimo per boost 'short' (secondi)")]
        [Range(10f, 60f)]
        public float minGapShort = 20f;

        [Tooltip("Gap minimo per boost 'long' (secondi)")]
        [Range(60f, 300f)]
        public float minGapLong = 120f;

        [Header("EMA Half-Life (Percezione Temporale)")]
        [Tooltip("Half-life breve per reazioni rapide (secondi)")]
        [Range(1f, 10f)]
        public float hlShort = 4f;

        [Tooltip("Half-life medio per pattern a media scala (secondi)")]
        [Range(10f, 30f)]
        public float hlMid = 15f;

        [Tooltip("Half-life lungo per trend persistenti (secondi)")]
        [Range(30f, 180f)]
        public float hlLong = 90f;

        [Header("Sistema Emotivo")]
        [Tooltip("Tempo minimo tra cambi di emozione (isteresi)")]
        [Range(1f, 15f)]
        public float emotionMinDwell = 5f;

        [Tooltip("Bias per stato CURIOUS")]
        [Range(-0.3f, 0.3f)]
        public float biasCurious = 0.12f;

        [Tooltip("Bias per stato BORED")]
        [Range(-0.3f, 0.3f)]
        public float biasBored = -0.08f;

        [Tooltip("Bias per stato IRRITATED")]
        [Range(-0.3f, 0.3f)]
        public float biasIrritated = 0.22f;

        [Header("Rate Limiting")]
        [Tooltip("Target interventi al minuto")]
        [Range(0.5f, 5f)]
        public float targetSpeakRatePerMin = 1.5f;

        [Header("Normalizzazione")]
        [Tooltip("Cap massimo per normalizzazione silenzio (secondi)")]
        [Range(60f, 600f)]
        public float maxSilenceCap = 300f;

        /// <summary>
        /// Crea una configurazione runtime con valori di default.
        /// Utile quando non si usa un ScriptableObject.
        /// </summary>
        public static TemporalConfig CreateDefault()
        {
            var config = CreateInstance<TemporalConfig>();
            // I valori di default sono già impostati nei field
            return config;
        }
    }
}
