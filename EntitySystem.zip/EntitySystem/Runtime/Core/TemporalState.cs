// EntitySystem/Runtime/Core/TemporalState.cs
// Stato interno del controller - percezione temporale e memoria

using System;
using UnityEngine;

namespace EntitySystem.Core
{
    /// <summary>
    /// Stato interno del TemporalController.
    /// Mantiene gli EMA multi-scala, contatori e stato emotivo.
    /// Serializzabile per debug e persistenza.
    /// </summary>
    [Serializable]
    public class TemporalState
    {
        #region Timeline
        
        [Header("Timeline")]
        [Tooltip("Timestamp dell'ultimo intervento")]
        public float lastSpokeAt;

        [Tooltip("Timestamp dell'ultimo evento percepito")]
        public float lastEventAt;

        [Tooltip("Timestamp dell'ultimo cambio di emozione")]
        public float lastEmotionChangeAt;

        #endregion

        #region Counters

        [Header("Contatori")]
        [Tooltip("Numero totale di interventi")]
        public int spokeCount;

        [Tooltip("Numero totale di silenzi")]
        public int ignoredCount;

        [Tooltip("Silenzi consecutivi (decade nel tempo)")]
        public int consecutiveSilence;

        #endregion

        #region EMA - Tension

        [Header("EMA Tensione")]
        [Tooltip("Tensione a breve termine")]
        [Range(0f, 1f)]
        public float emaTensionS;

        [Tooltip("Tensione a medio termine")]
        [Range(0f, 1f)]
        public float emaTensionM;

        [Tooltip("Tensione a lungo termine")]
        [Range(0f, 1f)]
        public float emaTensionL;

        #endregion

        #region EMA - Silence

        [Header("EMA Silenzio")]
        [Tooltip("Silenzio a breve termine")]
        [Range(0f, 1f)]
        public float emaSilenceS;

        [Tooltip("Silenzio a medio termine")]
        [Range(0f, 1f)]
        public float emaSilenceM;

        [Tooltip("Silenzio a lungo termine")]
        [Range(0f, 1f)]
        public float emaSilenceL;

        #endregion

        #region Rate & Emotion

        [Header("Rate & Emozione")]
        [Tooltip("Interventi al minuto (EMA)")]
        public float speakRatePerMin;

        [Tooltip("Stato emotivo corrente")]
        public EntityEmotion emotion = EntityEmotion.Curious;

        #endregion

        /// <summary>
        /// Inizializza lo stato con timestamp corrente.
        /// </summary>
        public void Initialize(float now)
        {
            lastSpokeAt = now;
            lastEventAt = now;
            lastEmotionChangeAt = now;
            spokeCount = 0;
            ignoredCount = 0;
            consecutiveSilence = 0;
            emaTensionS = 0f;
            emaTensionM = 0f;
            emaTensionL = 0f;
            emaSilenceS = 0f;
            emaSilenceM = 0f;
            emaSilenceL = 0f;
            speakRatePerMin = 0f;
            emotion = EntityEmotion.Curious;
        }

        /// <summary>
        /// Calcola l'aggiornamento EMA con interpretazione fisica dell'half-life.
        /// Formula: α = 1 - exp(-ln(2) * dt / halfLife)
        /// </summary>
        public static float EmaUpdate(float prev, float value, float dt, float halfLife)
        {
            if (halfLife <= 0f) return value;
            float alpha = 1f - Mathf.Exp(-Mathf.Log(2f) * Mathf.Max(dt, 0f) / halfLife);
            return (1f - alpha) * prev + alpha * value;
        }

        /// <summary>
        /// Restituisce il bias emotivo corrente.
        /// </summary>
        public float GetEmotionBias(TemporalConfig cfg)
        {
            return emotion switch
            {
                EntityEmotion.Curious => cfg.biasCurious,
                EntityEmotion.Bored => cfg.biasBored,
                EntityEmotion.Irritated => cfg.biasIrritated,
                _ => 0f
            };
        }

        /// <summary>
        /// Crea una copia dello stato (per logging/debug).
        /// </summary>
        public TemporalState Clone()
        {
            return new TemporalState
            {
                lastSpokeAt = this.lastSpokeAt,
                lastEventAt = this.lastEventAt,
                lastEmotionChangeAt = this.lastEmotionChangeAt,
                spokeCount = this.spokeCount,
                ignoredCount = this.ignoredCount,
                consecutiveSilence = this.consecutiveSilence,
                emaTensionS = this.emaTensionS,
                emaTensionM = this.emaTensionM,
                emaTensionL = this.emaTensionL,
                emaSilenceS = this.emaSilenceS,
                emaSilenceM = this.emaSilenceM,
                emaSilenceL = this.emaSilenceL,
                speakRatePerMin = this.speakRatePerMin,
                emotion = this.emotion
            };
        }
    }
}
