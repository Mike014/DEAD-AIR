// EntitySystem/Runtime/Core/EntityEmotion.cs
// Stati emotivi del Temporal Controller

namespace EntitySystem.Core
{
    /// <summary>
    /// Stati emotivi di ENTITÀ.
    /// Influenzano la probabilità di intervento tramite bias.
    /// Le transizioni hanno isteresi (minimo tempo di permanenza).
    /// </summary>
    public enum EntityEmotion
    {
        /// <summary>
        /// Stato di default. ENTITÀ è attenta e leggermente propensa a intervenire.
        /// Bias: +0.12
        /// </summary>
        Curious,

        /// <summary>
        /// ENTITÀ si annoia per bassa tensione e silenzio prolungato.
        /// Bias: -0.08 (meno propensa a intervenire)
        /// </summary>
        Bored,

        /// <summary>
        /// ENTITÀ è irritata da alta tensione combinata con silenzio.
        /// Bias: +0.22 (più propensa a intervenire)
        /// </summary>
        Irritated
    }
}
