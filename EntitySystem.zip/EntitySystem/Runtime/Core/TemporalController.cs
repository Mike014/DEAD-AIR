// EntitySystem/Runtime/Core/TemporalController.cs
// Port 1:1 del Temporal Controller Python - decide SE parlare

using System;
using UnityEngine;
using Random = UnityEngine.Random;

namespace EntitySystem.Core
{
    /// <summary>
    /// Decide SE ENTITÀ deve parlare, basandosi su:
    /// - Tensione narrativa corrente
    /// - Pattern di silenzio (EMA multi-scala)
    /// - Stato emotivo (con isteresi)
    /// - Rate limiting interno
    /// - Rumore stocastico
    /// 
    /// Port diretto del codice Python, stessa logica esatta.
    /// </summary>
    public class TemporalController
    {
        #region Public Properties

        /// <summary>
        /// Configurazione del controller.
        /// </summary>
        public TemporalConfig Config { get; }

        /// <summary>
        /// Stato interno (esposto per debug, non modificare direttamente).
        /// </summary>
        public TemporalState State => _state;

        /// <summary>
        /// Ultima probabilità calcolata (per debug/UI).
        /// </summary>
        public float LastProbability { get; private set; }

        /// <summary>
        /// Ultimo risultato di ShouldSpeak (per debug/UI).
        /// </summary>
        public bool LastDecision { get; private set; }

        /// <summary>
        /// Evento fired ad ogni decisione (per logging/analytics).
        /// </summary>
        public event Action<DecisionEvent> OnDecision;

        #endregion

        #region Private State

        private readonly TemporalState _state;
        private Func<float> _timeProvider;

        #endregion

        #region Constructors

        /// <summary>
        /// Crea un controller con configurazione custom.
        /// </summary>
        /// <param name="config">Configurazione (null = default)</param>
        /// <param name="timeProvider">Provider del tempo (null = Time.time)</param>
        public TemporalController(TemporalConfig config = null, Func<float> timeProvider = null)
        {
            Config = config != null ? config : TemporalConfig.CreateDefault();
            _timeProvider = timeProvider ?? (() => Time.time);
            _state = new TemporalState();
            _state.Initialize(_timeProvider());
        }

        #endregion

        #region Public API

        /// <summary>
        /// Decide se ENTITÀ deve parlare adesso.
        /// </summary>
        /// <param name="tension">Tensione narrativa [0-1]</param>
        /// <param name="silenceSec">Secondi di silenzio (null = calcola automaticamente)</param>
        /// <returns>True se ENTITÀ deve intervenire</returns>
        public bool ShouldSpeak(float tension, float? silenceSec = null)
        {
            float now = _timeProvider();
            float silence = silenceSec ?? (now - _state.lastSpokeAt);

            // Clamp input
            tension = Mathf.Clamp01(tension);
            silence = Mathf.Max(0f, silence);

            // Hard cooldown check
            if (now - _state.lastSpokeAt < Config.hardCooldown)
            {
                UpdatePerception(tension, silence, now);
                ObserveDecision(spoke: false, now);
                FireDecisionEvent(tension, silence, 0f, false, "cooldown");
                return false;
            }

            // Update perception
            UpdatePerception(tension, silence, now);

            // Calculate probability
            float p = CalculateProbability(tension, silence);
            LastProbability = p;

            // Stochastic decision
            bool speak = Random.value < p;
            LastDecision = speak;

            // Observe and feedback
            ObserveDecision(speak, now);
            FireDecisionEvent(tension, silence, p, speak, speak ? "speak" : "silence");

            return speak;
        }

        /// <summary>
        /// Reset dello stato interno.
        /// Utile per nuova sessione/scena.
        /// </summary>
        public void Reset()
        {
            _state.Initialize(_timeProvider());
            LastProbability = 0f;
            LastDecision = false;
        }

        /// <summary>
        /// Forza un intervento (bypassa il gate).
        /// Utile per eventi scriptati.
        /// </summary>
        public void ForceSpeak()
        {
            float now = _timeProvider();
            _state.lastSpokeAt = now;
            _state.spokeCount++;
            _state.consecutiveSilence = 0;
            LastDecision = true;
        }

        #endregion

        #region Private Methods

        private void UpdatePerception(float tension, float silenceSec, float now)
        {
            float dt = Mathf.Max(0.001f, now - _state.lastEventAt);
            _state.lastEventAt = now;

            // Normalize silence to [0,1] (60s = 1.0)
            float silenceNorm = Mathf.Clamp01(silenceSec / 60f);

            // Update EMAs
            _state.emaTensionS = TemporalState.EmaUpdate(_state.emaTensionS, tension, dt, Config.hlShort);
            _state.emaTensionM = TemporalState.EmaUpdate(_state.emaTensionM, tension, dt, Config.hlMid);
            _state.emaTensionL = TemporalState.EmaUpdate(_state.emaTensionL, tension, dt, Config.hlLong);

            _state.emaSilenceS = TemporalState.EmaUpdate(_state.emaSilenceS, silenceNorm, dt, Config.hlShort);
            _state.emaSilenceM = TemporalState.EmaUpdate(_state.emaSilenceM, silenceNorm, dt, Config.hlMid);
            _state.emaSilenceL = TemporalState.EmaUpdate(_state.emaSilenceL, silenceNorm, dt, Config.hlLong);

            // Update consecutive silence (leaky)
            if (silenceNorm > 0.5f)
                _state.consecutiveSilence++;
            else if (dt > Config.hlShort)
                _state.consecutiveSilence = Mathf.Max(0, _state.consecutiveSilence - 1);

            // Update emotion with hysteresis
            UpdateEmotion(now);
        }

        private void UpdateEmotion(float now)
        {
            // Hysteresis: minimum dwell time
            if (now - _state.lastEmotionChangeAt < Config.emotionMinDwell)
                return;

            float tM = _state.emaTensionM;
            float sS = _state.emaSilenceS;
            float sM = _state.emaSilenceM;
            float sL = _state.emaSilenceL;
            bool spokeRecently = (now - _state.lastSpokeAt) < 8f;

            bool lowTension = tM < 0.45f;
            bool highTension = tM > 0.55f;
            bool highSilence = sS > 0.40f || sM > 0.35f || sL > 0.30f;
            bool veryHighSilence = sS > 0.60f || sM > 0.50f || sL > 0.45f;

            EntityEmotion newEmotion = _state.emotion;

            if (veryHighSilence || (highTension && highSilence))
                newEmotion = EntityEmotion.Irritated;
            else if (lowTension && highSilence)
                newEmotion = EntityEmotion.Bored;
            else if (spokeRecently || sS < 0.25f)
                newEmotion = EntityEmotion.Curious;

            if (newEmotion != _state.emotion)
            {
                _state.emotion = newEmotion;
                _state.lastEmotionChangeAt = now;
            }
        }

        private float CalculateProbability(float tension, float silenceSec)
        {
            // Temporal boost
            float temporalBoost = 0f;
            if (silenceSec >= Config.minGapLong)
                temporalBoost = 0.25f;
            else if (silenceSec >= Config.minGapShort)
                temporalBoost = 0.15f;
            else if (silenceSec >= Config.minGapMicro)
                temporalBoost = 0.05f;

            // Rate term (penalty if talking too much, bonus if too quiet)
            float rate = _state.speakRatePerMin;
            float rateTerm = 0f;
            if (rate > Config.targetSpeakRatePerMin)
                rateTerm = -Mathf.Min(0.30f, (rate - Config.targetSpeakRatePerMin) * 0.06f);
            else
                rateTerm = Mathf.Min(0.10f, (Config.targetSpeakRatePerMin - rate) * 0.02f);

            // Memory term (weighted silence EMAs)
            float memoryTerm = 0.40f * _state.emaSilenceM + 0.60f * _state.emaSilenceL;

            // Emotion bias
            float emotionBias = _state.GetEmotionBias(Config);

            // Random noise
            float noise = (Random.value - 0.5f) * 2f; // [-1, 1]

            // Combine
            float p = Config.baseProb
                + Config.wTension * ((tension - 0.5f) * 2f)
                + Config.wMemory * memoryTerm
                + Config.wEmotion * emotionBias
                + Config.wTemporal * temporalBoost
                + rateTerm
                + Config.wRandom * noise;

            // Clamp
            return Mathf.Clamp(p, Config.probFloor, Config.probCeil);
        }

        private void ObserveDecision(bool spoke, float now)
        {
            if (spoke)
            {
                _state.spokeCount++;
                _state.consecutiveSilence = 0;

                // Update speak rate (impulse)
                float impulseRate = _state.lastSpokeAt > 0f
                    ? 60f / Mathf.Max(0.001f, now - _state.lastSpokeAt)
                    : Config.targetSpeakRatePerMin;
                _state.speakRatePerMin = TemporalState.EmaUpdate(
                    _state.speakRatePerMin, impulseRate, 1f, Config.hlMid);

                _state.lastSpokeAt = now;
            }
            else
            {
                _state.ignoredCount++;

                // Drift toward target
                _state.speakRatePerMin = TemporalState.EmaUpdate(
                    _state.speakRatePerMin, Config.targetSpeakRatePerMin * 0.6f, 1f, Config.hlLong);
            }
        }

        private void FireDecisionEvent(float tension, float silence, float p, bool speak, string reason)
        {
            OnDecision?.Invoke(new DecisionEvent
            {
                Timestamp = _timeProvider(),
                Tension = tension,
                SilenceSec = silence,
                Probability = p,
                Speak = speak,
                Reason = reason,
                Emotion = _state.emotion,
                EmaTensionS = _state.emaTensionS,
                EmaTensionM = _state.emaTensionM,
                EmaTensionL = _state.emaTensionL,
                EmaSilenceS = _state.emaSilenceS,
                EmaSilenceM = _state.emaSilenceM,
                EmaSilenceL = _state.emaSilenceL
            });
        }

        #endregion
    }

    /// <summary>
    /// Evento di decisione per logging/analytics.
    /// Corrisponde a una riga del CSV Python.
    /// </summary>
    public struct DecisionEvent
    {
        public float Timestamp;
        public float Tension;
        public float SilenceSec;
        public float Probability;
        public bool Speak;
        public string Reason;
        public EntityEmotion Emotion;
        public float EmaTensionS;
        public float EmaTensionM;
        public float EmaTensionL;
        public float EmaSilenceS;
        public float EmaSilenceM;
        public float EmaSilenceL;
    }
}
