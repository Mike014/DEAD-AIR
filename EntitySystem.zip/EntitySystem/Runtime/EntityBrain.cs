// EntitySystem/Runtime/EntityBrain.cs
// MonoBehaviour principale - integra TemporalController + GroqClient

using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using EntitySystem.Core;
using EntitySystem.LLM;

namespace EntitySystem
{
    /// <summary>
    /// Componente principale di ENTITÀ per Unity.
    /// Combina il Temporal Controller (decisione locale) con il client LLM (generazione remota).
    /// 
    /// Uso tipico:
    /// 1. Aggiungi questo componente a un GameObject
    /// 2. Configura il TemporalConfig (ScriptableObject o valori inline)
    /// 3. Chiama Query() quando vuoi che ENTITÀ consideri di parlare
    /// 4. Ascolta OnEntitySpeak per la risposta
    /// </summary>
    public class EntityBrain : MonoBehaviour
    {
        #region Inspector

        [Header("Configuration")]
        [Tooltip("Configurazione del Temporal Controller (null = default)")]
        [SerializeField] private TemporalConfig _config;

        [Tooltip("API Key Groq (lascia vuoto per usare env var)")]
        [SerializeField] private string _apiKey;

        [Tooltip("Modello Groq da usare")]
        [SerializeField] private string _model = "llama-3.3-70b-versatile";

        [Tooltip("Temperatura per la generazione")]
        [Range(0f, 1f)]
        [SerializeField] private float _temperature = 0.2f;

        [Header("Debug")]
        [Tooltip("Log delle decisioni in console")]
        [SerializeField] private bool _debugLog = true;

        [Tooltip("Stato corrente (read-only)")]
        [SerializeField] private TemporalState _currentState;

        [Header("Events")]
        public UnityEvent<string> OnEntitySpeak;
        public UnityEvent OnEntitySilence;
        public UnityEvent<DecisionEvent> OnDecision;

        #endregion

        #region Public Properties

        /// <summary>
        /// Controller interno (per accesso avanzato).
        /// </summary>
        public TemporalController Controller => _controller;

        /// <summary>
        /// Emozione corrente di ENTITÀ.
        /// </summary>
        public EntityEmotion CurrentEmotion => _controller?.State?.emotion ?? EntityEmotion.Curious;

        /// <summary>
        /// Ultima probabilità calcolata.
        /// </summary>
        public float LastProbability => _controller?.LastProbability ?? 0f;

        /// <summary>
        /// True se una query è in corso.
        /// </summary>
        public bool IsQuerying => _isQuerying;

        #endregion

        #region Private State

        private TemporalController _controller;
        private GroqClient _groqClient;
        private bool _isQuerying;
        private float _lastQueryTime;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            InitializeController();
            InitializeClient();
        }

        private void OnValidate()
        {
            // Sync debug state in inspector
            if (_controller != null)
                _currentState = _controller.State.Clone();
        }

        #endregion

        #region Initialization

        private void InitializeController()
        {
            _controller = new TemporalController(_config);

            if (_debugLog)
            {
                _controller.OnDecision += LogDecision;
            }

            _controller.OnDecision += evt => OnDecision?.Invoke(evt);
        }

        private void InitializeClient()
        {
            string key = string.IsNullOrEmpty(_apiKey) ? null : _apiKey;
            _groqClient = new GroqClient(key, _model, _temperature);
        }

        #endregion

        #region Public API

        /// <summary>
        /// Chiede a ENTITÀ di considerare se parlare.
        /// Il Temporal Controller decide localmente, poi (se sì) chiama Groq.
        /// </summary>
        /// <param name="dialogContext">Contesto del dialogo</param>
        /// <param name="tension">Tensione narrativa [0-1]</param>
        /// <param name="silenceSec">Secondi di silenzio (null = automatico)</param>
        public void Query(string dialogContext, float tension, float? silenceSec = null)
        {
            if (_isQuerying)
            {
                if (_debugLog)
                    Debug.Log("[EntityBrain] Query già in corso, ignorata.");
                return;
            }

            StartCoroutine(QueryCoroutine(dialogContext, tension, silenceSec));
        }

        /// <summary>
        /// Versione async-friendly di Query.
        /// </summary>
        public Coroutine QueryAsync(string dialogContext, float tension, float? silenceSec = null)
        {
            if (_isQuerying)
                return null;

            return StartCoroutine(QueryCoroutine(dialogContext, tension, silenceSec));
        }

        /// <summary>
        /// Reset completo dello stato.
        /// </summary>
        public void Reset()
        {
            _controller?.Reset();
            _lastQueryTime = 0f;
            
            if (_debugLog)
                Debug.Log("[EntityBrain] Reset completo.");
        }

        /// <summary>
        /// Forza ENTITÀ a parlare (bypassa il gate).
        /// </summary>
        public void ForceSpeak(string dialogContext)
        {
            if (_isQuerying)
                return;

            _controller?.ForceSpeak();
            StartCoroutine(GenerateOnly(dialogContext));
        }

        #endregion

        #region Query Logic

        private IEnumerator QueryCoroutine(string dialogContext, float tension, float? silenceSec)
        {
            _isQuerying = true;
            _lastQueryTime = Time.time;

            // Sync state for inspector
            _currentState = _controller.State.Clone();

            // GATE: Local decision
            bool shouldSpeak = _controller.ShouldSpeak(tension, silenceSec);

            // Sync state again after decision
            _currentState = _controller.State.Clone();

            if (!shouldSpeak)
            {
                if (_debugLog)
                    Debug.Log($"[EntityBrain] SILENZIO (p={_controller.LastProbability:F2}, emo={CurrentEmotion})");

                OnEntitySilence?.Invoke();
                _isQuerying = false;
                yield break;
            }

            // GENERATE: Remote LLM call
            if (_debugLog)
                Debug.Log($"[EntityBrain] Gate aperto (p={_controller.LastProbability:F2}), chiamo Groq...");

            EntityResponse response = default;
            yield return _groqClient.GenerateResponse(dialogContext, r => response = r);

            _isQuerying = false;

            if (response.Success && !string.IsNullOrEmpty(response.Text))
            {
                if (_debugLog)
                    Debug.Log($"[EntityBrain] PARLA: \"{response.Text}\" ({response.ApiMs:F0}ms)");

                OnEntitySpeak?.Invoke(response.Text);
            }
            else
            {
                if (_debugLog)
                    Debug.Log($"[EntityBrain] Nessun candidato valido, silenzio forzato.");

                OnEntitySilence?.Invoke();
            }
        }

        private IEnumerator GenerateOnly(string dialogContext)
        {
            _isQuerying = true;

            EntityResponse response = default;
            yield return _groqClient.GenerateResponse(dialogContext, r => response = r);

            _isQuerying = false;

            if (response.Success && !string.IsNullOrEmpty(response.Text))
            {
                OnEntitySpeak?.Invoke(response.Text);
            }
        }

        #endregion

        #region Debug

        private void LogDecision(DecisionEvent evt)
        {
            string tensionStr = $"T({evt.EmaTensionS:F2}/{evt.EmaTensionM:F2}/{evt.EmaTensionL:F2})";
            string silenceStr = $"S({evt.EmaSilenceS:F2}/{evt.EmaSilenceM:F2}/{evt.EmaSilenceL:F2})";
            Debug.Log($"[EntityBrain] {evt.Reason.ToUpper()} | p={evt.Probability:F2} | {evt.Emotion} | {tensionStr} {silenceStr}");
        }

        #endregion
    }
}
