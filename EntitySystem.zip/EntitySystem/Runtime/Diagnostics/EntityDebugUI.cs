// EntitySystem/Runtime/Diagnostics/EntityDebugUI.cs
// UI di debug per visualizzare lo stato di ENTITÀ

using UnityEngine;
using EntitySystem.Core;

namespace EntitySystem.Diagnostics
{
    /// <summary>
    /// UI di debug per visualizzare lo stato di ENTITÀ in tempo reale.
    /// Usa OnGUI per semplicità (no dipendenze UI).
    /// </summary>
    public class EntityDebugUI : MonoBehaviour
    {
        [Header("Configuration")]
        [SerializeField] private EntityBrain _brain;

        [SerializeField] private bool _showUI = true;
        [SerializeField] private KeyCode _toggleKey = KeyCode.F1;

        [Header("Position")]
        [SerializeField] private float _x = 10f;
        [SerializeField] private float _y = 10f;
        [SerializeField] private float _width = 300f;

        private GUIStyle _boxStyle;
        private GUIStyle _labelStyle;
        private GUIStyle _headerStyle;

        private void Awake()
        {
            if (_brain == null)
                _brain = FindObjectOfType<EntityBrain>();
        }

        private void Update()
        {
            if (Input.GetKeyDown(_toggleKey))
                _showUI = !_showUI;
        }

        private void OnGUI()
        {
            if (!_showUI || _brain == null || _brain.Controller == null)
                return;

            InitStyles();

            var state = _brain.Controller.State;
            var config = _brain.Controller.Config;

            float y = _y;
            float lineHeight = 20f;
            float padding = 5f;

            // Background box
            float boxHeight = lineHeight * 18 + padding * 2;
            GUI.Box(new Rect(_x, y, _width, boxHeight), "", _boxStyle);

            y += padding;

            // Header
            GUI.Label(new Rect(_x + padding, y, _width - padding * 2, lineHeight), "ENTITÀ DEBUG", _headerStyle);
            y += lineHeight + 5;

            // Emotion
            string emotionColor = state.emotion switch
            {
                EntityEmotion.Curious => "#00FF00",
                EntityEmotion.Bored => "#FFFF00",
                EntityEmotion.Irritated => "#FF0000",
                _ => "#FFFFFF"
            };
            GUI.Label(new Rect(_x + padding, y, _width, lineHeight),
                $"<color={emotionColor}>● {state.emotion}</color>", _labelStyle);
            y += lineHeight;

            // Probability
            float p = _brain.LastProbability;
            GUI.Label(new Rect(_x + padding, y, _width, lineHeight),
                $"Probability: {p:F2} ({(int)(p * 100)}%)", _labelStyle);
            y += lineHeight;

            // Bar visualization
            DrawBar(_x + padding, y, _width - padding * 2, 10f, p, Color.cyan);
            y += 15f;

            // Tension EMAs
            GUI.Label(new Rect(_x + padding, y, _width, lineHeight), "Tension:", _labelStyle);
            y += lineHeight;

            DrawLabeledBar("S", state.emaTensionS, _x + padding, y, _width - padding * 2, Color.red);
            y += 15f;
            DrawLabeledBar("M", state.emaTensionM, _x + padding, y, _width - padding * 2, Color.red);
            y += 15f;
            DrawLabeledBar("L", state.emaTensionL, _x + padding, y, _width - padding * 2, Color.red);
            y += 20f;

            // Silence EMAs
            GUI.Label(new Rect(_x + padding, y, _width, lineHeight), "Silence:", _labelStyle);
            y += lineHeight;

            DrawLabeledBar("S", state.emaSilenceS, _x + padding, y, _width - padding * 2, Color.blue);
            y += 15f;
            DrawLabeledBar("M", state.emaSilenceM, _x + padding, y, _width - padding * 2, Color.blue);
            y += 15f;
            DrawLabeledBar("L", state.emaSilenceL, _x + padding, y, _width - padding * 2, Color.blue);
            y += 20f;

            // Counters
            GUI.Label(new Rect(_x + padding, y, _width, lineHeight),
                $"Spoke: {state.spokeCount} | Ignored: {state.ignoredCount}", _labelStyle);
            y += lineHeight;

            // Rate
            GUI.Label(new Rect(_x + padding, y, _width, lineHeight),
                $"Rate: {state.speakRatePerMin:F1}/min (target: {config.targetSpeakRatePerMin:F1})", _labelStyle);
            y += lineHeight;

            // Time since last spoke
            float silenceSec = Time.time - state.lastSpokeAt;
            GUI.Label(new Rect(_x + padding, y, _width, lineHeight),
                $"Silence: {silenceSec:F1}s", _labelStyle);
        }

        private void InitStyles()
        {
            if (_boxStyle != null) return;

            _boxStyle = new GUIStyle(GUI.skin.box)
            {
                normal = { background = MakeTexture(2, 2, new Color(0, 0, 0, 0.8f)) }
            };

            _labelStyle = new GUIStyle(GUI.skin.label)
            {
                richText = true,
                fontSize = 12,
                normal = { textColor = Color.white }
            };

            _headerStyle = new GUIStyle(GUI.skin.label)
            {
                richText = true,
                fontSize = 14,
                fontStyle = FontStyle.Bold,
                normal = { textColor = Color.cyan }
            };
        }

        private void DrawBar(float x, float y, float width, float height, float value, Color color)
        {
            // Background
            GUI.DrawTexture(new Rect(x, y, width, height), MakeTexture(1, 1, new Color(0.2f, 0.2f, 0.2f)));

            // Fill
            float fillWidth = width * Mathf.Clamp01(value);
            GUI.DrawTexture(new Rect(x, y, fillWidth, height), MakeTexture(1, 1, color));
        }

        private void DrawLabeledBar(string label, float value, float x, float y, float width, Color color)
        {
            GUI.Label(new Rect(x, y - 2, 20, 15), label, _labelStyle);
            DrawBar(x + 25, y, width - 70, 10f, value, color);
            GUI.Label(new Rect(x + width - 40, y - 2, 40, 15), $"{value:F2}", _labelStyle);
        }

        private static Texture2D MakeTexture(int width, int height, Color color)
        {
            var tex = new Texture2D(width, height);
            var pixels = new Color[width * height];
            for (int i = 0; i < pixels.Length; i++)
                pixels[i] = color;
            tex.SetPixels(pixels);
            tex.Apply();
            return tex;
        }
    }
}
