// EntitySystem/Runtime/Diagnostics/EntityMetricsLogger.cs
// Logger CSV compatibile con il formato Python

using System;
using System.IO;
using System.Text;
using UnityEngine;
using EntitySystem.Core;

namespace EntitySystem.Diagnostics
{
    /// <summary>
    /// Logger per metriche di ENTITÀ.
    /// Genera un CSV compatibile con il formato Python per analisi unificate.
    /// </summary>
    public class EntityMetricsLogger : MonoBehaviour
    {
        [Header("Configuration")]
        [Tooltip("Path del file CSV (relativo a persistentDataPath)")]
        [SerializeField] private string _fileName = "entita_metrics.csv";

        [Tooltip("EntityBrain da monitorare")]
        [SerializeField] private EntityBrain _brain;

        [Tooltip("Abilita logging")]
        [SerializeField] private bool _enabled = true;

        private string _filePath;
        private bool _headerWritten;

        private static readonly string[] Headers = {
            "ts", "event", "model", "decision_ms", "p", "speak",
            "api_ms", "toks_in", "toks_out", "end_to_end_ms",
            "tension_s", "tension_m", "tension_l",
            "silence_s", "silence_m", "silence_l", "emotion"
        };

        private void Awake()
        {
            _filePath = Path.Combine(Application.persistentDataPath, _fileName);

            if (_brain == null)
                _brain = GetComponent<EntityBrain>();

            if (_brain == null)
            {
                Debug.LogError("[EntityMetricsLogger] EntityBrain non trovato!");
                return;
            }

            // Subscribe to events
            _brain.OnDecision.AddListener(OnDecision);
        }

        private void Start()
        {
            if (_enabled && !_headerWritten)
            {
                WriteHeader();
            }

            Debug.Log($"[EntityMetricsLogger] Logging to: {_filePath}");
        }

        private void OnDestroy()
        {
            if (_brain != null)
                _brain.OnDecision.RemoveListener(OnDecision);
        }

        private void WriteHeader()
        {
            if (File.Exists(_filePath))
            {
                _headerWritten = true;
                return;
            }

            try
            {
                File.WriteAllText(_filePath, string.Join(",", Headers) + "\n", Encoding.UTF8);
                _headerWritten = true;
            }
            catch (Exception e)
            {
                Debug.LogError($"[EntityMetricsLogger] Failed to write header: {e.Message}");
            }
        }

        private void OnDecision(DecisionEvent evt)
        {
            if (!_enabled) return;

            try
            {
                var sb = new StringBuilder();

                // ts
                sb.Append(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0);
                sb.Append(',');

                // event
                sb.Append(evt.Reason);
                sb.Append(',');

                // model (hardcoded for now)
                sb.Append("unity-native");
                sb.Append(',');

                // decision_ms (not tracked at this level)
                sb.Append(',');

                // p
                sb.Append(evt.Probability.ToString("F3"));
                sb.Append(',');

                // speak
                sb.Append(evt.Speak ? "True" : "False");
                sb.Append(',');

                // api_ms, toks_in, toks_out, end_to_end_ms (filled by response handler)
                sb.Append(",,,,");

                // tension_s, tension_m, tension_l
                sb.Append(evt.EmaTensionS.ToString("F4"));
                sb.Append(',');
                sb.Append(evt.EmaTensionM.ToString("F4"));
                sb.Append(',');
                sb.Append(evt.EmaTensionL.ToString("F4"));
                sb.Append(',');

                // silence_s, silence_m, silence_l
                sb.Append(evt.EmaSilenceS.ToString("F4"));
                sb.Append(',');
                sb.Append(evt.EmaSilenceM.ToString("F4"));
                sb.Append(',');
                sb.Append(evt.EmaSilenceL.ToString("F4"));
                sb.Append(',');

                // emotion
                sb.Append(evt.Emotion.ToString().ToLower());

                sb.Append('\n');

                File.AppendAllText(_filePath, sb.ToString(), Encoding.UTF8);
            }
            catch (Exception e)
            {
                Debug.LogError($"[EntityMetricsLogger] Failed to log: {e.Message}");
            }
        }

        /// <summary>
        /// Log manuale di una risposta (per tracciare API latency).
        /// </summary>
        public void LogResponse(float apiMs, int tokensIn, int tokensOut, float endToEndMs)
        {
            if (!_enabled) return;

            try
            {
                var line = $"{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0},response,unity-native,,,,{apiMs:F3},{tokensIn},{tokensOut},{endToEndMs:F3},,,,,,\n";
                File.AppendAllText(_filePath, line, Encoding.UTF8);
            }
            catch (Exception e)
            {
                Debug.LogError($"[EntityMetricsLogger] Failed to log response: {e.Message}");
            }
        }

        /// <summary>
        /// Cancella il file di log.
        /// </summary>
        [ContextMenu("Clear Log")]
        public void ClearLog()
        {
            if (File.Exists(_filePath))
            {
                File.Delete(_filePath);
                _headerWritten = false;
                WriteHeader();
                Debug.Log("[EntityMetricsLogger] Log cleared.");
            }
        }
    }
}
